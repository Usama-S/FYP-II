﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RouteOptimization.Models
{
    public class RiderFitness
    {
        // rider ID
        public decimal driver_id { get; set; }

        // rider's fitness value.
        public double rider_fitness { get; set; }
    }
}